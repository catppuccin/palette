package org.catppuccin.flavor.domain;

public enum FlavorName {
    LATTE("latte"),
    FRAPPE("frappe"),
    MACCHIATO("macchiato"),
    MOCHA("mocha");

    private final String name;

    FlavorName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
