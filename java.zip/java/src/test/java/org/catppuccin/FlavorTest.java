package org.catppuccin;

import java.util.stream.Stream;
import org.catppuccin.flavor.Flavor;
import org.catppuccin.flavor.Frappe;
import org.catppuccin.flavor.Latte;
import org.catppuccin.flavor.Macchiato;
import org.catppuccin.flavor.Mocha;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class FlavorTest {

    @ParameterizedTest
    @MethodSource("getFlavoursForBase")
    void shouldReturnHex(Flavor flavor, String baseHex) {
        assertThat(flavor.getBase().getHex(), is(baseHex));
    }

    @Test
    void shouldReturnHSB() {
        Flavor mocha = new Mocha();
        float[] expectedHSB = new float[3];
        expectedHSB[0] = 240.0F/360.0F;
        expectedHSB[1] = 0.3478261F;
        expectedHSB[2] = 0.18039216F;

        assertThat(mocha.getBase().getHSB(), is(expectedHSB));
    }

    @Test
    void shouldReturnHSBWhenGivenArray() {
        Flavor mocha = new Mocha();
        float[] actualHSB = new float[3];

        mocha.getBase().getHSB(actualHSB);

        assertThat(actualHSB[0], is(240.0F/360.F));
        assertThat(actualHSB[1], is(0.3478261F));
        assertThat(actualHSB[2], is(0.18039216F));
    }

    private static Stream<Arguments> getFlavoursForBase() {
        return Stream.of(
            Arguments.of(new Latte(), "#eff1f5"),
            Arguments.of(new Frappe(), "#303446"),
            Arguments.of(new Macchiato(), "#24273a"),
            Arguments.of(new Mocha(), "#1e1e2e")
        );
    }
}
